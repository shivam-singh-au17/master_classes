// WHOM AM I ?
//     Create a file named whoAmI.js You have learnt about polygons in maths.So basically write switch cases which takes into account the number of side of a polygon and accordingly name it.

// numOfSides = 3, then output should be triangle
// numOfSides = 4, then output should be quadrilateral 
// numOfSides = 5, then output should be pentagon 
// numOfSides = 6, then output should be hexagon

var numOfSides = 6;

if (numOfSides == 3) {
    console.log("triangle");
}
else if (numOfSides == 4) {
    console.log("quadrilateral");
}
else if (numOfSides == 5) {
    console.log("pentagon");
}
else if (numOfSides == 6) {
    console.log("hexagon");
}
else if (numOfSides == 7) {
    console.log("heptagon");
}
else if (numOfSides == 8) {
    console.log("octagon");
}
else if (numOfSides == 9) {
    console.log("nonagon");
}
else{
    console.log("Please refer google");
}





