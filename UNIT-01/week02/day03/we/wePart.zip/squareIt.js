// SQUARE IT
// Create a file named squareIt.js.For the numbers from 1 to 10, print the square of the numbers.The output should be in the following format.

// Note Do it with both the for loop and while loop


// using for loop

for (var i = 1; i <= 10; i++){
    console.log(`The square of ${i} is ${i*i}`);
}


// using while loop

var i = 1;
while (i <= 10) {
    console.log(`The square of ${i} is ${i*i}`);
    i++
}