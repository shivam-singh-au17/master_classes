var current_year = 2021;
var year_birth = 1998;

calculate_age = (current_year - year_birth);
console.log(calculate_age)