var maths = 73;
var english = 83;
var hindi = 62;

total_mark = (maths + english + hindi);
parsentage = total_mark / 300 * 100
console.log(parsentage)