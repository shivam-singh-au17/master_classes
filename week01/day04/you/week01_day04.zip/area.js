length = 17;
breadth = 10;

area = (length * breadth);
console.log(area);

perimeter = 2 * (length + breadth);
console.log(perimeter);
