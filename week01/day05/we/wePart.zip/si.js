/*
The siple interest formula is
SI = (p * r * t / 100)
*/

var principal = 100000; // this is the principal amount
var rate = 8;  // This is the rate in percent annum
var time = 5; //This is the time in year

var sipleIntrest = (principal * rate * time) / 100;
console.log(sipleIntrest);

