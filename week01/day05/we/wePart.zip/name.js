
var averageAge = 26;
var numberOfStudent = 205;
var maximumMarks = 100;
var theFirstName = "Shivam";
var numberOfStudentIn12ThClass = 53;
