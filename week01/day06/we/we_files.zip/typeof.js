
var a = 1729; //number
console.log(typeof a);

var b = "Masai School"; // string
console.log(typeof b);

var c = true; // boolean
console.log(typeof c);

var d = "";  // string
console.log(typeof d);

var e = undefined; //undefined
console.log(typeof e);
