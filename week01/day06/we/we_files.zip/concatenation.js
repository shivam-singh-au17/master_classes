
var firstName = "Shivam";
var lastName = "Singh";
var age = "23";
var address = "Rajauli Chunar";
var city = "Mirzapur";
var state = "Uttar Pradesh";
var picCode = "231301";

console.log("My name is " + firstName + " " + lastName);
console.log(`My name is ${firstName} ${lastName}`);
